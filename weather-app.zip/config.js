// Kendi OpenWeatherMap anahtarını yaz. Bu dosya GitHub'a gitmez (.gitignore).
const API_KEY = "BURAYA_OPENWEATHERMAP_ANAHTARI";
