// Bu dosyayı "config.js" adıyla kopyala ve kendi anahtarını yaz.
const API_KEY = "BURAYA_OPENWEATHERMAP_ANAHTARI";
