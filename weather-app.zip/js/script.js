// Hafta 4'te API çağrısı (fetch) buraya eklenecek.
// API_KEY, config.js dosyasından gelir.
console.log("Petek Weather App yüklendi");
